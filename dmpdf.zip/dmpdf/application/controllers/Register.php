<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('weblogin_model');
		
	}
	
	public function index()
	{
		$this->load->view('careers');
	}

	public  function check_login()
    {
      $data=$this->input->post();
      $data=array_map('trim',$data);
      unset($data['signin']);
      
      $result=$this->weblogin_model->check_login($data);
       if($result){
            $response=1; //true
            if($this->session->userdata('is_form_fill')=='Yes')
            {
                redirect('register/myprofile');    
            }else{
                redirect('register/vacancy');//add personal details page address here
            }
            
          }else{
            $this->session->set_flashdata('message','<b>Error : Invalid login credentials</b>');
            $response=0; //false
            redirect('register','refresh');
          }
          //echo json_encode($response);
    }
    public function logout()
    { 
      $this->session->set_flashdata('message','<b>Logout successfully</b>');
      $this->session->sess_destroy();
      redirect('register');
	}
	

	public function register_can(){
		$data=$this->input->post();
		$data=array_map('trim',$data);
        unset($data['confirmsignup']);  
        
		$response=$this->weblogin_model->add_registration($data);
		if($response==1)
		{
		  $this->session->set_flashdata('message', '<b>Success : Registered successfully please login to proceed</b>');
		}else if($response==0)
		{
		  $this->session->set_flashdata('message', '<b>Error : Unable to process data</b>');
		}
        else if($response==2)
		{
		  $this->session->set_flashdata('message', '<b>Error : Email id already exists in database </b>');
		}		
		redirect('register','refresh');
	}

    public function save_personal(){
        $data=$this->input->post();
        $data=array_map('trim',$data);
        $data=array_map('strip_tags',$data);
       
        $image_name1='';
         if($_FILES['can_photo']['name']!=""){
			$new_name=$_FILES['can_photo']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/personal';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('can_photo')){
			  $error = array('error' => $this->upload->display_errors());
                //print_r($error);
			}
			else{
				$upload_data=$this->upload->data();
				$image_name1=$upload_data['file_name'];
			  }
			}

            $image_name2='';

            if($_FILES['can_sign']['name']!=""){
			$new_name=$_FILES['can_sign']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/personal';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);

			if (!$this->upload->do_upload('can_sign')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name2=$upload_data['file_name'];
			  }
			}
			
            date_default_timezone_set("Asia/Kolkata");
			$data['added_on']=date('Y-m-d H:i:s');
            $data['can_photo']=$image_name1;
			$data['can_sign']=$image_name2;
			$data=array_map('trim', $data);
            
            $result=$this->weblogin_model->save_personal($data);
            
            //$result=$this->weblogin_model->update_personal($data);	
    }

    public function save_education(){
        $data=$this->input->post();
         $data=array_map('trim',$data);
        $data=array_map('strip_tags',$data);
        //echo '<pre>';print_r($data);
        $result=$this->weblogin_model->save_education($data);
    }

    public function save_documents(){
        $data=$this->input->post();
        $image_name1='';
            /* upload  matric marksheet */
        if($_FILES['matric_marksheet']['name']!=""){
			$new_name=$_FILES['matric_marksheet']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('matric_marksheet')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name1=$upload_data['file_name'];
			  }
			}
            $image_name2='';
                /* upload  int_marksheet */
        if($_FILES['int_marksheet']['name']!=""){
			$new_name=$_FILES['int_marksheet']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('int_marksheet')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name2=$upload_data['file_name'];
			  }
			}
            $image_name3='';
             /* upload  Grad marksheet */
        if($_FILES['grad_marksheet']['name']!=""){
			$new_name=$_FILES['grad_marksheet']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('grad_marksheet')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name3=$upload_data['file_name'];
			  }
			}

            /* upload  pg marksheet */
            $image_name4='';
        if($_FILES['pg_marksheet']['name']!=""){
			$new_name=$_FILES['pg_marksheet']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('pg_marksheet')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name4=$upload_data['file_name'];
			  }
			}

            /* upload  other marksheet */
            $image_name5='';
        if($_FILES['other_marksheet']['name']!=""){
			$new_name=$_FILES['other_marksheet']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('other_marksheet')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name5=$upload_data['file_name'];
			  }
			}

           

            /* upload  exrtra ach */
            $image_name6='';
        if($_FILES['extra_ach']['name']!=""){
			$new_name=$_FILES['extra_ach']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('extra_ach')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name6=$upload_data['file_name'];
			  }
			}

            /* upload  dd */
            $image_name7='';
        if($_FILES['dd_upload']['name']!=""){
			$new_name=$_FILES['dd_upload']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('dd_upload')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name7=$upload_data['file_name'];
			  }
			}

            /* upload  id proof */
            $image_name8='';
        if($_FILES['id_proof']['name']!=""){
			$new_name=$_FILES['id_proof']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('id_proof')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name8=$upload_data['file_name'];
			  }
			}
            
            $data['matric_marksheet']=$image_name1;
            $data['int_marksheet']=$image_name2;
            $data['grad_marksheet']=$image_name3;
            $data['pg_marksheet']=$image_name4;
            $data['other_marksheet']=$image_name5;
            $data['extra_ach']=$image_name6;
            $data['dd_upload']=$image_name7;
            $data['id_proof']=$image_name8;

        $result=$this->weblogin_model->save_documents($data);

        if($response==1)
		{
        
		  redirect('register/view_profile');
		}else
		{
            
		  $this->session->set_flashdata('message', '<b>Error : Unable to process data</b>');
		} 
        //redirect('register/myprofile');
    }

    public function vacancy(){
        $data['states']=$this->db->get('states')->result_array();
        $this->load->view('vacancy',$data);
    }

    public function load_cities($state_id){
        //$state_id=$this->input->post('id');
        $this->db->where('state_id',$state_id);
        $data=$this->db->get('cities')->result_array();
        echo json_encode($data);
    }

    public function myprofile(){
        $id=$this->session->userdata('id');
        $this->db->where('reg_id',$id);
        $data['personal_data']=$this->db->get('tbl_canprofile')->result_array();
        
        $this->db->where('reg_id',$id);
        $data['education_data']=$this->db->get('tbl_can_education')->result_array();

        $this->db->where('reg_id',$id);
        $data['document_data']=$this->db->get('tbl_can_documents')->result_array();
       //echo '<pre>';print_r($data);exit();
        $this->load->view('myprofile',$data);
    }

   
   
    

    public function save_all_data(){

		/** save first form */
			
		$image_name11='';
		if($_FILES['can_photo']['name']!=""){
		   $new_name=$_FILES['can_photo']['name'];
			 
		   $config['file_name']=$new_name;
		   $config['upload_path'] = 'assetsweb/uploads/img_career/personal';
		   $config['allowed_types'] =     'jpg|png|jpeg';
		   $config['encrypt_name'] = true;
		   $this->load->library('upload', $config);
		   
		   if (!$this->upload->do_upload('can_photo')){
			 $error = array('error' => $this->upload->display_errors());
			   //print_r($error);
		   }
		   else{
			   $upload_data=$this->upload->data();
			   $image_name11=$upload_data['file_name'];
			 }
		   }

		   $image_name22='';

		   if($_FILES['can_sign']['name']!=""){
		   $new_name=$_FILES['can_sign']['name'];
			 
		   $config['file_name']=$new_name;
		   $config['upload_path'] = 'assetsweb/uploads/img_career/personal';
		   $config['allowed_types'] =     'jpg|png|jpeg';
		   $config['encrypt_name'] = true;
		   $this->load->library('upload', $config);

		   if (!$this->upload->do_upload('can_sign')){
			 $error = array('error' => $this->upload->display_errors());
		   }
		   else{
			   $upload_data=$this->upload->data();
			   $image_name22=$upload_data['file_name'];
			 }
		   }
		   
		   date_default_timezone_set("Asia/Kolkata");
		   $data['added_on']=date('Y-m-d H:i:s');
		   $data['can_photo']=$image_name11;
		   $data['can_sign']=$image_name22;
		   

		/** save second form */

		/** save third form */
		$image_name1='';
            /* upload  matric marksheet */
        if($_FILES['matric_marksheet']['name']!=""){
			$new_name=$_FILES['matric_marksheet']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('matric_marksheet')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name1=$upload_data['file_name'];
			  }
			}
            $image_name2='';
                /* upload  int_marksheet */
        if($_FILES['int_marksheet']['name']!=""){
			$new_name=$_FILES['int_marksheet']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('int_marksheet')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name2=$upload_data['file_name'];
			  }
			}
            $image_name3='';
             /* upload  Grad marksheet */
        if($_FILES['grad_marksheet']['name']!=""){
			$new_name=$_FILES['grad_marksheet']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('grad_marksheet')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name3=$upload_data['file_name'];
			  }
			}

            /* upload  pg marksheet */
            $image_name4='';
        if($_FILES['pg_marksheet']['name']!=""){
			$new_name=$_FILES['pg_marksheet']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('pg_marksheet')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name4=$upload_data['file_name'];
			  }
			}

            /* upload  other marksheet */
            $image_name5='';
        if($_FILES['other_marksheet']['name']!=""){
			$new_name=$_FILES['other_marksheet']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('other_marksheet')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name5=$upload_data['file_name'];
			  }
			}

           

            /* upload  exrtra ach */
            $image_name6='';
        if($_FILES['extra_ach']['name']!=""){
			$new_name=$_FILES['extra_ach']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('extra_ach')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name6=$upload_data['file_name'];
			  }
			}

            /* upload  dd */
            $image_name7='';
        if($_FILES['dd_upload']['name']!=""){
			$new_name=$_FILES['dd_upload']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('dd_upload')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name7=$upload_data['file_name'];
			  }
			}

            /* upload  id proof */
            $image_name8='';
        if($_FILES['id_proof']['name']!=""){
			$new_name=$_FILES['id_proof']['name'];
			  
			$config['file_name']=$new_name;
			$config['upload_path'] = 'assetsweb/uploads/img_career/docs';
			$config['allowed_types'] =     'jpg|png|jpeg';
			$config['encrypt_name'] = true;
			$this->load->library('upload', $config);
			
			if (!$this->upload->do_upload('id_proof')){
			  $error = array('error' => $this->upload->display_errors());
			}
			else{
				$upload_data=$this->upload->data();
				$image_name8=$upload_data['file_name'];
			  }
			}
            
            $data['matric_marksheet']=$image_name1;
            $data['int_marksheet']=$image_name2;
            $data['grad_marksheet']=$image_name3;
            $data['pg_marksheet']=$image_name4;
            $data['other_marksheet']=$image_name5;
            $data['extra_ach']=$image_name6;
            $data['dd_upload']=$image_name7;
			$data['id_proof']=$image_name8;

			$data=array_map('trim', $data);
			
			$response=$this->weblogin_model->save_career_application($data);

			if($response==1)
			{
			
			  redirect('register/view_profile');
			}else
			{
				
			  $this->session->set_flashdata('message', '<b>Error : Unable to process data</b>');
			} 
			
    }

}